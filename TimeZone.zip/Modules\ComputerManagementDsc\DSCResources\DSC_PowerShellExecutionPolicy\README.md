# Description

This resource allows configuration of the PowerShell execution
policy for different execution scopes.
